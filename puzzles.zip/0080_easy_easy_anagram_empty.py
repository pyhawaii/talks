# easy anagram: challenge #80

# This puzzle comes from the reddit/r/dailyprogrammer website and is the basis for a
# group mentoring session for PyHawaii.

# ============================================================================
# NOTE: this file is an empty shell to populate with your answer.
# See the file <puzzle_name>_solution.py for a solution you can use to
# compare to your own.
# ============================================================================

# Paraphrasing from the reddit.com/r/dailyprogrammer website...
#   You will be given a text file with words, one word per line... 113809of.fic
#   All words that are anagrams of each other are considered members of an Anagram Family.
#   You will also be given a target word. Your task is to find the size of the Anagram
#       Family that word falls into.
#   As a bonus, find the largest Anagram Family or Families.


def reddit(text):
    # Add your code here...






if __name__ == '__main__':

    assert reddit('grapes') == 7
    assert reddit('marbles') == 5
    assert reddit('dog') == 2
    assert reddit('cat') == 6
    assert reddit('zzzzz') == 0
    print('All tests ran succesfully')