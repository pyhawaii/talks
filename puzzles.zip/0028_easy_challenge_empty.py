# easy challenge: #28

# This puzzle comes from the reddit/r/dailyprogrammer website and is the basis for a
# group mentoring session for PyHawaii.

# ============================================================================
# NOTE: this file is an empty shell to populate with your answer.
# See the file <puzzle_name>_solution.py for a solution you can use to
# compare to your own.
# ============================================================================

# Paraphrasing from the reddit.com/r/dailyprogrammer website...
#    The 'array duplicates problem' is when one integer is in an array appears
#    more than once.
#    You are given a file with integers between 1 and 1,000,000, separated by 
#    commas
#    One integer is in the file twice. How can you determine which one?
#    Your task is to write code to solve the challenge.
#    NOTE: try to find the most efficient way to solve this challenge.

# Add your code here...