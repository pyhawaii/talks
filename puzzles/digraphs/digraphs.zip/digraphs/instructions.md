# Find the message hidden in the digraphs

The file (name_time.csv) has names and times. Calculate the difference
between the times, by subtracting the first time on the line from the
second time on the line.

IF the difference between the times is equal to 42 seconds, make a note of the
name on the line.

The file (name_digraph.csv) has names and digraphs

Using the names you collected from the name_time.csv file,
identify all the lines in the name_digraph.csv with those names
and collect the digraphs.

Print the digraphs to spell out a secret message.
