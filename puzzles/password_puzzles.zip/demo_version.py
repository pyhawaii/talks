# For this sequence of puzzles, the objective is to solve for the following characteristics...
#     * How long is the shortest password(s) in the list?
#     * How long is the longest password(s) in the list?
#     * How many passwords:
#          > include only lowercase (no numbers or symbols either)?
#          > include only uppercase (no numbers or symbols either)?
#          > include both upper and lowercase (no numbers or symbols)?
#          > include upper, lowercase and numbers (but no symbols)?
#          > include all four characteristics: upper, lowercase, numbers AND symbols?
#    * What password(s) has the most unique characters: ie. 'abc12!' has six unique characters, but 'qqqqqqq'
#      has only one unique character?
#    * What password(s) has the least unique characters?

# To get you started...
# Put the password file and this script in the same folder and run this script to see
# some of the passwords.

fin = open('password_list.txt')
lines = fin.readlines()

# This is a somewhat naive way to clean the password in the list: lines.
# in the meetup, we will look at a more Pythonic way to do this
clean_pws = []
for password in lines:
    password = password.strip()
    clean_pws.append(password)

print(clean_pws)